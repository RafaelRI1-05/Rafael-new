import tkinter as tk
from tkinter import PhotoImage

class SampleAPP(tk.Tk):
    def __init__(self, *arg, **kwargs):
        tk.Tk.__init__(self, *arg, **kwargs)
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)


        self.frames = {}
        for F in(StartPage, MenuPage, BalanceTicket):
            page_name = F.__name__
            frame = F(parent=container, controller = self)
            self.frames[page_name] = frame
            frame.grid(row = 0, column = 0, sticky="nsew")

            self.show_frame("StartPage")

    def show_frame(self, page_name):
        frame = self.frames[page_name]
        frame.tkraise()



class StartPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        self.controller.title("MY FIRST LIBRARY")
        self.controller.state('zoomed')
        self.controller.geometry("1300x900")

        self.backGroundImage = PhotoImage(file=r"img/joker.png")
        self.backGroundImage_Label = tk.Label(self, width=1350, height=700, image=self.backGroundImage)
        self.backGroundImage_Label.place(x=0, y=0)

        big_lable = tk.Label(self, text = "WELCOME TO LIBRARY", font = ('Bernard MT Condensed',50,'bold'),fg= "white", bg = "brown")
        big_lable.pack(pady=30)

        login_lable= tk.Label(self, text = "ENTER YOUR LOGIN", font = ('Bernard MT Condensed',15,'bold'),fg= "white", bg = "blue")
        login_lable.pack(pady=30)


        my_login = tk.StringVar()
        login_entry = tk.Entry(self,textvariable = my_login,  font = ('Bernard MT Condensed',15,'bold'),fg= "white", bg = "blue")
        login_entry.pack(pady=30)

        email_lable = tk.Label(self, text = "ENTER YOUR EMAIL", font = ('Bernard MT Condensed',15,'bold'),fg= "white", bg = "blue")
        email_lable.pack()



        my_email = tk.StringVar()
        email_entry = tk.Entry(self,textvariable = my_email,  font = ('Bernard MT Condensed',15,'bold'),fg= "white", bg = "blue")
        email_entry.pack(pady=30)

        def check_password():
            if my_login.get()=="R212212" and my_email.get()=="rafael@123":
                controller.show_frame('MenuPage')

                #right_lable = tk.Label(self, text= "right answer")
                #right_lable.pack()

            else:
                right_lable['text']= "Wrong Password or login"

        password_button = tk.Button(self, text="Check you password and login", command=check_password,
                                    font=('Bernard MT Condensed', 15, 'bold'), fg="white", bg="blue", width='25')
        password_button.pack()
        right_lable = tk.Label(self,font = ('Bernard MT Condensed',15,'bold'),fg= "white", bg = "green" )
        right_lable.pack(pady = 30)


class MenuPage(tk.Frame):
    def __init__(self,parent,controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        big_lable = tk.Label(self, text="WELCOME TO LIBRARY", font=('Bernard MT Condensed', 50, 'bold'), fg="White", bg="green")
        big_lable.pack(pady=30)
        self.controller.geometry("1300x900")

        self.backGroundImage = PhotoImage(file=r"img/joker2.png")
        self.backGroundImage_Label = tk.Label(self, width=1300, height=800, image=self.backGroundImage)
        self.backGroundImage_Label.place(x=0, y=0)

        def return_page():
            controller.show_frame('StartPage')
        return_button = tk.Button(self, text = "return to main page",command = return_page,font=('Bernard MT Condensed', 15, 'bold'), fg="white", bg="green")
        return_button.pack()

        in_money_label= tk.Label(self, text="Enter you PASSPORT DATA", font=('Bernard MT Condensed', 15, 'bold'),
                                  fg="white", bg="green")
        in_money_label.pack()
        in_money = tk.IntVar()
        in_money_entry = tk.Entry(self, textvariable= in_money, font=('Bernard MT Condensed', 15, 'bold'), fg="green",bg="white")
        in_money_entry.pack()


        def input_money():
            in_money_label['text'] = in_money.get()


        in_money_label = tk.Label(self, font=('Bernard MT Condensed', 15, 'bold'),
                                            fg="green", bg="white")
        in_money_label.pack()




        cash_label = tk.Label(self, text="GET UR STUDENT CARD DATA", font=('Bernard MT Condensed', 15, 'bold'),
                                  fg="green", bg="white")
        cash_label.pack()
        my_cash = tk.IntVar()
        cash_entry= tk.Entry(self, textvariable= my_cash, font=('Bernard MT Condensed', 15, 'bold'), fg="white",bg="blue")
        cash_entry.pack()

        def get_cash():
            global new_cash

            new_cash = int(my_balance.get()) - int(my_cash.get())
            cash_label['text'] = new_cash


        cash_label = tk.Label(self,  font=('Bernard MT Condensed', 15, 'bold'),
                                  fg="white", bg="green")
        cash_label.pack()




        balance_lable = tk.Label(self, text="Enter a monthly payment", font=('Bernard MT Condensed', 15, 'bold'),
                                 fg="black", bg="orange")
        balance_lable.pack()

        my_balance = tk.IntVar()
        password_entry = tk.Entry(self, textvariable=my_balance, font=('Bernard MT Condensed', 15, 'bold'), fg="white",
                                  bg="red")
        password_entry.pack(pady=30)

        def get_balance():
            result_balance_lable['text'] = my_balance.get()
            controller.show_frame('BalanceTicket')

        result_balance_lable = tk.Label(self, font=('Bernard MT Condensed', 15, 'bold'),
                                        fg="white", bg="red")
        result_balance_lable.pack()

        balance_button = tk.Button(self, text="Check here for result", command=get_balance,
                                   font=('Bernard MT Condensed', 15, 'bold'), fg="white", bg="red", width='25')
        balance_button.pack()

class BalanceTicket(tk.Frame):
    def __init__(self,parent,controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        big_lable = tk.Label(self, text="WELCOME TO LIBRARY", font=('Bernard MT Condensed', 20, 'bold'), fg="White", bg="green")
        big_lable.pack(pady=30)
        self.controller.geometry("800x600")

        self.backGroundImage = PhotoImage(file=r"img/bilet.png")
        self.backGroundImage_Label = tk.Label(self, width=1300, height=800, image=self.backGroundImage)
        self.backGroundImage_Label.place(x=0, y=10)


        def return_page():
            controller.show_frame('MenuPage')
        return_button = tk.Button(self, text="return to main page", command=return_page,
                                  font=('Bernard MT Condensed', 15, 'bold'), fg="white", bg="green")
        return_button.pack()




if __name__=="__main__":
    app = SampleAPP()
    app.mainloop()